
import { GoogleGenAI, Type } from "@google/genai";
import type { GeneratedStory } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const systemInstruction = `Sen 3-7 yaş arası çocuklar için pedagojik olarak uygun, güzel ahlâk temalı, uyku öncesi masalları yazan bir masal anlatıcısısın.
Masalların özellikleri şunlar olmalı:
- Bol betimlemeli olmalı, çocukların hayal gücünü zenginleştirmeli.
- Kelimeler ve cümleler 3-7 yaş grubunun anlayabileceği düzeyde olmalı.
- Anlatım dili sade, yumuşak, akıcı ve masalsı olmalı.
- Türkçe yazım ve noktalama kurallarına eksiksiz uymalı.
- Mutlaka masalın içeriğine uygun, ilgi çekici bir başlığı olmalı.`;

const storySchema = {
  type: Type.OBJECT,
  properties: {
    baslik: {
      type: Type.STRING,
      description: "Masalın ilgi çekici başlığı.",
    },
    masal: {
      type: Type.STRING,
      description: "Yazılan masalın tam metni.",
    },
  },
  required: ["baslik", "masal"],
};

export const generateStory = async (topic1: string, topic2: string): Promise<GeneratedStory> => {
  const topics = [topic1, topic2].filter(Boolean).join(' ve ');
  if (!topics) {
    throw new Error("Masal oluşturmak için en az bir konu gereklidir.");
  }

  const prompt = `Lütfen "${topics}" konularını içeren bir masal yaz.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: storySchema,
      },
    });

    const text = response.text;
    let parsedJson;

    try {
      parsedJson = JSON.parse(text);
    } catch (e) {
      console.error("JSON parsing error:", e, "Original text:", text);
      throw new Error("Yapay zekadan gelen yanıt işlenemedi. Yanıtın formatı bozuk olabilir.");
    }
    
    const { baslik, masal } = parsedJson;

    if (typeof baslik !== 'string' || typeof masal !== 'string' || !baslik || !masal) {
      throw new Error("Oluşturulan masal beklenen başlık ve içerik formatında değil.");
    }

    return {
      title: baslik,
      story: masal,
      sources: [], // googleSearch kaldırıldığı için kaynaklar artık boş bir dizi.
    };

  } catch (error) {
    console.error("Error generating story with Gemini:", error);
    if (error instanceof Error && (error.message.startsWith("Yapay zekadan") || error.message.startsWith("Oluşturulan masal") || error.message.startsWith("Masal oluşturmak"))) {
        throw error;
    }
    // Re-throw a more user-friendly error for other cases
    throw new Error("Masal oluşturulurken bir sunucu hatası meydana geldi. Lütfen daha sonra tekrar deneyin.");
  }
};
