
import React, { useState } from 'react';
import { SparklesIcon } from './icons';

interface StoryFormProps {
  onGenerate: (topic1: string, topic2: string) => void;
  isLoading: boolean;
  initialTopics: [string, string];
}

export const StoryForm: React.FC<StoryFormProps> = ({ onGenerate, isLoading, initialTopics }) => {
  const [topic1, setTopic1] = useState(initialTopics[0]);
  const [topic2, setTopic2] = useState(initialTopics[1]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(topic1, topic2);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-white/70 backdrop-blur-sm p-6 sm:p-8 rounded-2xl shadow-lg">
      <form onSubmit={handleSubmit} className="space-y-6">
        <h2 className="text-2xl font-bold text-center text-slate-700">Masalımız ne hakkında olsun?</h2>
        <p className="text-center text-slate-500 -mt-4">Bir veya iki konu belirleyebilirsiniz.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="topic1" className="block text-sm font-bold text-slate-600 mb-2">
              Konu 1
            </label>
            <input
              id="topic1"
              type="text"
              value={topic1}
              onChange={(e) => setTopic1(e.target.value)}
              placeholder="Örn: Paylaşmak"
              className="w-full px-4 py-3 text-lg text-slate-700 bg-white border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-purple-400 transition-shadow duration-200"
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="topic2" className="block text-sm font-bold text-slate-600 mb-2">
              Konu 2 (İsteğe Bağlı)
            </label>
            <input
              id="topic2"
              type="text"
              value={topic2}
              onChange={(e) => setTopic2(e.target.value)}
              placeholder="Örn: Ormandaki hayvanlar"
              className="w-full px-4 py-3 text-lg text-slate-700 bg-white border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-400 transition-shadow duration-200"
              disabled={isLoading}
            />
          </div>
        </div>
        <div className="pt-2">
          <button
            type="submit"
            disabled={isLoading || (!topic1 && !topic2)}
            className="w-full flex items-center justify-center gap-3 px-6 py-4 text-xl font-bold text-white bg-purple-600 rounded-full hover:bg-purple-700 transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-300 disabled:bg-purple-300 disabled:cursor-not-allowed disabled:transform-none"
          >
            <SparklesIcon className="h-6 w-6" />
            <span>Sihirli Masalı Oluştur</span>
          </button>
        </div>
      </form>
    </div>
  );
};