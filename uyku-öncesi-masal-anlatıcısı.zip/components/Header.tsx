
import React from 'react';
import { MoonIcon } from './icons';

export const Header: React.FC = () => {
  return (
    <header className="text-center">
        <div className="inline-flex items-center justify-center gap-3">
            <MoonIcon className="h-10 w-10 text-purple-500" />
            <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-800 tracking-tight">
                Uyku Öncesi Masal Anlatıcısı
            </h1>
        </div>
        <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
            Çocuğunuzun hayal dünyasını zenginleştirecek, güzel ahlâk temalı, sihirli masallar oluşturun.
        </p>
    </header>
  );
};