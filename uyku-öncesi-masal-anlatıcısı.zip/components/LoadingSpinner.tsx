
import React from 'react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="text-center p-10">
      <div className="flex justify-center items-center space-x-2">
        <div className="w-5 h-5 rounded-full animate-pulse bg-purple-400"></div>
        <div className="w-5 h-5 rounded-full animate-pulse bg-blue-400" style={{ animationDelay: '0.2s' }}></div>
        <div className="w-5 h-5 rounded-full animate-pulse bg-purple-400" style={{ animationDelay: '0.4s' }}></div>
      </div>
      <p className="mt-6 text-xl text-slate-600 font-semibold">
        Sihirli masalınız hazırlanıyor...
      </p>
    </div>
  );
};