import React, { useState, useEffect, useCallback, useMemo } from 'react';
import type { GeneratedStory } from '../types';
import { BookOpenIcon, LinkIcon, ArrowPathIcon, SpeakerWaveIcon, PlayIcon, PauseIcon, StopIcon } from './icons';

interface StoryDisplayProps {
  storyData: GeneratedStory;
  onReset: () => void;
}

export const StoryDisplay: React.FC<StoryDisplayProps> = ({ storyData, onReset }) => {
  const { title, story, sources } = storyData;

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isAudioSupported, setIsAudioSupported] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [voiceName, setVoiceName] = useState<string>('');
  const [activeSentenceIndex, setActiveSentenceIndex] = useState(-1);

  // Memoize sentence splitting. This regex is designed to split by punctuation or newlines,
  // keeping the delimiters as part of the sentence, which preserves paragraph structure.
  const sentences = useMemo(() => {
    if (!story) return [];
    return story.match(/[^.!?\n]+(?:[.!?]+|\n{1,}|$)/g)?.filter(s => s.trim()) || [];
  }, [story]);

  // Memoize the calculation of character ranges for each sentence.
  // This is used by the 'onboundary' event to find the currently spoken sentence.
  const sentenceRanges = useMemo(() => {
    let runningCharCount = 0;
    return sentences.map(sentence => {
      const start = runningCharCount;
      runningCharCount += sentence.length;
      return { start, end: runningCharCount };
    });
  }, [sentences]);

  useEffect(() => {
    if ('speechSynthesis' in window) {
      setIsAudioSupported(true);

      const getAndSetVoice = () => {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length === 0) return;

        const turkishVoices = voices.filter(v => v.lang === 'tr-TR');
        if (turkishVoices.length === 0) {
          setVoiceName('Türkçe ses bulunamadı');
          return;
        }
        
        const preferredVoiceOrder = ["Vindemiatrix", "Callirrhoe", "Leda", "Zubenelgenubi", "Microsoft Tolga - Turkish (Turkey)"];
        let voice: SpeechSynthesisVoice | undefined;

        for (const name of preferredVoiceOrder) {
          voice = turkishVoices.find(v => v.name === name);
          if (voice) break;
        }

        if (!voice) {
          voice = turkishVoices[0];
        }
        setSelectedVoice(voice);
        setVoiceName(voice.name);
      };

      getAndSetVoice();
      window.speechSynthesis.addEventListener('voiceschanged', getAndSetVoice);

      return () => {
        window.speechSynthesis.removeEventListener('voiceschanged', getAndSetVoice);
        if (window.speechSynthesis.speaking) {
          window.speechSynthesis.cancel();
        }
      };
    }
  }, []);

  const handlePlay = useCallback(() => {
    if (!isAudioSupported || !selectedVoice || sentences.length === 0) return;

    window.speechSynthesis.cancel(); // Cancel any lingering speech

    // Reconstruct the story from sentences to ensure char indices match our ranges.
    const textToSpeak = sentences.join('');
    const utterance = new SpeechSynthesisUtterance(textToSpeak);

    utterance.voice = selectedVoice;
    utterance.lang = 'tr-TR';
    utterance.rate = 0.8;
    utterance.pitch = 0.9;

    utterance.onboundary = (event) => {
      // 'word' boundary is the most reliable across browsers.
      if (event.name === 'word') {
        const charIndex = event.charIndex;
        // Find which sentence range the current character index falls into.
        const currentIndex = sentenceRanges.findIndex(range => charIndex >= range.start && charIndex < range.end);
        // Use a functional update to avoid stale state in the callback.
        setActiveSentenceIndex(prevIndex => (currentIndex !== -1 && currentIndex !== prevIndex) ? currentIndex : prevIndex);
      }
    };

    utterance.onstart = () => { setIsSpeaking(true); setIsPaused(false); setActiveSentenceIndex(0); };
    utterance.onpause = () => { setIsPaused(true); };
    utterance.onresume = () => { setIsPaused(false); };
    utterance.onend = () => { setIsSpeaking(false); setIsPaused(false); setActiveSentenceIndex(-1); };
    utterance.onerror = () => { setIsSpeaking(false); setIsPaused(false); setActiveSentenceIndex(-1); };

    window.speechSynthesis.speak(utterance);
  }, [isAudioSupported, selectedVoice, sentences, sentenceRanges]);

  const handleResume = useCallback(() => window.speechSynthesis.resume(), []);
  const handlePause = useCallback(() => window.speechSynthesis.pause(), []);

  const handleStop = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel(); // This will trigger onend which resets state, including activeSentenceIndex
    }
  }, []);

  const handleResetClick = () => {
    handleStop();
    onReset();
  };

  const renderAudioControls = () => {
    if (!isAudioSupported || !selectedVoice) {
      return null;
    }

    if (!isSpeaking) {
      return (
        <button
          onClick={handlePlay}
          className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-green-500 rounded-full hover:bg-green-600 transition-all duration-300 shadow-md transform hover:scale-105"
          aria-label="Bu masalı sesli dinle"
        >
          <SpeakerWaveIcon className="h-5 w-5" />
          <span>Bu masalı sesli dinle</span>
        </button>
      );
    }

    return (
      <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-full shadow-inner">
        <button
          onClick={isPaused ? handleResume : handlePause}
          className="p-2 text-slate-700 bg-white rounded-full shadow hover:bg-slate-50 transition-colors"
          aria-label={isPaused ? 'Devam Et' : 'Duraklat'}
        >
          {isPaused ? <PlayIcon className="h-5 w-5" /> : <PauseIcon className="h-5 w-5" />}
        </button>
        <button
          onClick={handleStop}
          className="p-2 text-slate-700 bg-white rounded-full shadow hover:bg-slate-50 transition-colors"
          aria-label="Durdur"
        >
          <StopIcon className="h-5 w-5" />
        </button>
      </div>
    );
  };

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl p-6 sm:p-8 lg:p-10 animate-fade-in">
      <div className="flex items-center gap-4 mb-6 border-b border-purple-200 pb-4">
        <div className="flex-shrink-0 bg-purple-100 rounded-full p-3">
          <BookOpenIcon className="h-8 w-8 text-purple-600" />
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-800">{title}</h2>
      </div>

      <div className="mb-6">
        {renderAudioControls()}
        {isAudioSupported && (
          <p className="text-xs text-slate-500 mt-2">
            {selectedVoice
              ? <>Anlatıcı Ses: <span className="font-semibold">{voiceName}</span></>
              : 'Anlatıcı ses yükleniyor...'
            }
          </p>
        )}
      </div>

      <div className="prose prose-lg max-w-none text-slate-700 leading-relaxed whitespace-pre-wrap">
        {sentences.map((sentence, index) => (
            <span
                key={index}
                className={`transition-colors duration-300 rounded-md ${index === activeSentenceIndex ? 'bg-purple-200/70' : 'bg-transparent'}`}
            >
                {sentence}
            </span>
        ))}
      </div>

      {sources && sources.length > 0 && (
        <div className="mt-10 pt-6 border-t border-purple-200">
          <h3 className="text-lg font-bold text-slate-700 flex items-center gap-2">
            <LinkIcon className="h-5 w-5 text-slate-500" />
            İnternet Kaynakları
          </h3>
          <p className="text-sm text-slate-500 mb-3">Bu masal oluşturulurken aşağıdaki kaynaklardan ilham alınmıştır:</p>
          <ul className="space-y-2">
            {sources.map((source, index) => (
              <li key={index}>
                <a
                  href={source.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-purple-600 hover:text-purple-800 hover:underline transition-colors duration-200 text-sm"
                >
                  {source.title || source.uri}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-10 text-center">
        <button
          onClick={handleResetClick}
          className="inline-flex items-center justify-center gap-2 px-8 py-3 text-lg font-bold text-white bg-blue-500 rounded-full hover:bg-blue-600 transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300"
        >
          <ArrowPathIcon className="h-6 w-6" />
          Yeni Bir Masal Yaz
        </button>
      </div>
    </div>
  );
};
